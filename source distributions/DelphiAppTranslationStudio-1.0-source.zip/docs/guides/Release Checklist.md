# Release Checklist

Last changed: September 1, 2026

- Confirm `.git/index.lock` is absent or remove it only when zero bytes and no
  Git process is running.
- Confirm no API keys or credential-like values appear in tracked files.
- Build Debug and Release for Win32 and Win64 with the RAD Studio 37.0
  environment.
- Run `tools\tests\RunPhase10ReleaseValidation.ps1` and require one uninterrupted
  pass of the complete Debug/Release Win32/Win64 matrix.
- Confirm core, VCL, FMX, package, designer streaming, selector, foundation,
  runtime, integration, Studio form, launch, and self-localization suites pass.
- Run the deterministic provider-contract VCL and FMX reference pilots under
  Win32 and Win64. Require protected-field review, AI Draft provenance, final
  review/approval, and the Italian title on launch.
- Verify unfinished-session recovery restores the exact pre-AI snapshot and
  that concurrent or protected JSON changes are rejected rather than merged.
- Treat live provider testing as optional external acceptance. If performed,
  use an owner-supplied restricted test key and never store it in fixtures or
  logs.
- When provider instructions change, confirm Google and DeepL endpoint and
  authentication details against current official provider documentation.
- Generate VCL and FMX Component Integration kits and verify their JSON packs,
  English source pack, component/runtime units, manifest, README, component
  installer, verified BPL set, and deployment script.
- Hash every selected target project and form before and after kit generation;
  require byte-for-byte equality and zero target writes.
- Build and stream the matching VCL/FMX Win32 design packages and the Win32 and
  Win64 runtime packages in Debug and Release.
- Confirm each design BPL imports no custom DAT runtime BPL, and verify the
  manual RAD Studio package-installation instructions before an installation
  test. Automatic package installation must remain unavailable.
- Confirm Studio result lists have stable row heights, workflow status guidance
  changes per page, catalog path navigation works, validation issues navigate to
  entries, and large-catalog review/approval actions preserve excluded work.
- Verify the required typed language selector populates validated packs and
  changes the linked manager while preserving inherited `OnChange` behavior.
  A connected designer-authored language menu is the supported alternative.
- Verify the Setup Wizard displays the exact detected `ApplicationId`,
  atomically refreshes the project-local
  `dependencies\DelphiAppTranslation` folder, uses only a process-local Search
  Path for Studio-initiated builds, deploys packs directly to existing output
  folders, and leaves Pascal source, form resources, `.dpr`, and `.dproj` files
  byte-for-byte unchanged.
- Verify target-source Apply, Restore, and Complete Reset remain disabled and
  that Component Integration is the only available integration workflow.
- Verify that target preferences are written under `%LOCALAPPDATA%` and packs
  are read from `Localization\Languages` beside the executable.
- Regenerate the editable DOCX guides from the reviewed source-backed guide builder.
- Export companion PDFs with LibreOffice using an isolated user profile.
- Do not use Microsoft Word for this project documentation workflow.
- Render and inspect every documentation PDF page.
- Confirm the TOC-to-content transition starts on a new page, page numbering
  restarts correctly, and there are no blank, clipped, or overlapping pages.
- Build the source distribution without `bin`, `dcu`, `export`, credentials, or
  user-specific settings.
- Review Git status, stage only intended files, commit clearly, and push every
  configured public and private remote.
